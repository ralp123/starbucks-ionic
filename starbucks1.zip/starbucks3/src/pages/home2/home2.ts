import { Component } from '@angular/core';


@Component({
  selector: 'page-home2',
  templateUrl: 'home2.html'
})
export class HomePage2 {
  constructor() {

  }

}
