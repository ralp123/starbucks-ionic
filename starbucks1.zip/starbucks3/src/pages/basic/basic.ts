import { Component } from '@angular/core';


@Component({
  selector: 'page-basic',
  templateUrl: 'basic.html'
})
export class BasicPage {
  constructor() {

  }
}
